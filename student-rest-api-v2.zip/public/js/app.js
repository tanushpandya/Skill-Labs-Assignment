/* StudentHub front-end — vanilla JS, talks to the REST API at /api */
(() => {
  'use strict';

  const API = '/api';
  const $ = (sel, el = document) => el.querySelector(sel);

  // ---------- State ----------
  const state = {
    page: 1,
    limit: 8,
    search: '',
    course: '',
    year: '',
    sort: 'id:desc',
    view: localStorage.getItem('view') || 'grid',
    items: [],
    courses: [],
    editingId: null,
    deleteId: null,
  };

  // ---------- Icons ----------
  const ICON = {
    edit: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>',
    trash: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="m6 6 1 14h10l1-14"/></svg>',
    sun: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>',
    moon: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z"/></svg>',
  };

  // ---------- Helpers ----------
  const esc = (v) =>
    String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const initials = (name) =>
    name.trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join('').toUpperCase();

  const hue = (name) => [...name].reduce((h, ch) => (h * 31 + ch.charCodeAt(0)) % 360, 7);

  const tier = (cgpa) =>
    typeof cgpa !== 'number' ? 'tier-none' : cgpa >= 8.5 ? 'tier-high' : cgpa >= 7 ? 'tier-mid' : 'tier-low';

  const debounce = (fn, ms = 300) => {
    let t;
    return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
  };

  async function api(path, options = {}) {
    const res = await fetch(API + path, { headers: { 'Content-Type': 'application/json' }, ...options });
    if (res.status === 204) return null;
    const body = await res.json().catch(() => ({}));
    if (!res.ok) {
      const err = new Error(body.error?.message || 'Request failed');
      err.status = res.status;
      err.details = body.error?.details;
      throw err;
    }
    return body;
  }

  function toast(message, type = 'success') {
    const el = document.createElement('div');
    el.className = `toast ${type === 'error' ? 'error' : ''}`;
    el.innerHTML = `<span>${type === 'error' ? '⚠️' : '✅'}</span><span>${esc(message)}</span>`;
    $('#toasts').appendChild(el);
    setTimeout(() => {
      el.classList.add('out');
      setTimeout(() => el.remove(), 260);
    }, 3200);
  }

  // ---------- Theme ----------
  function renderThemeIcon() {
    const dark = document.documentElement.getAttribute('data-theme') === 'dark';
    $('#themeToggle').innerHTML = dark ? ICON.sun : ICON.moon;
  }
  $('#themeToggle').addEventListener('click', () => {
    const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('theme', next);
    renderThemeIcon();
  });

  // ---------- Stats ----------
  async function loadStats() {
    try {
      const { data } = await api('/students/stats');
      state.courses = data.byCourse.map((c) => c.course);

      const top = data.topStudent;
      const cards = [
        { icon: '👩‍🎓', tint: '#6366f1', label: 'Total students', value: data.total, sub: `${data.byYear.length} year group${data.byYear.length === 1 ? '' : 's'}` },
        { icon: '📈', tint: '#10b981', label: 'Average CGPA', value: data.averageCgpa ?? '—', sub: 'across graded students' },
        { icon: '📚', tint: '#f59e0b', label: 'Courses', value: data.byCourse.length, sub: data.byCourse[0] ? `Most: ${data.byCourse[0].course}` : 'No courses yet' },
        { icon: '🏆', tint: '#a855f7', label: 'Top performer', value: top ? top.cgpa : '—', sub: top ? top.name : 'No grades yet' },
      ];
      $('#stats').innerHTML = cards.map((c) => `
        <div class="stat" style="--tint:${c.tint}">
          <div class="stat-icon">${c.icon}</div>
          <div class="stat-label">${c.label}</div>
          <div class="stat-value">${esc(c.value)}</div>
          <div class="stat-sub" title="${esc(c.sub)}">${esc(c.sub)}</div>
        </div>`).join('');

      renderCourseBars(data.byCourse);
      renderCourseOptions();
    } catch (err) {
      $('#stats').innerHTML = '';
    }
  }

  function renderCourseBars(list) {
    const panel = $('#coursePanel');
    panel.hidden = list.length === 0;
    const max = Math.max(...list.map((c) => c.count), 1);
    $('#courseBars').innerHTML = list.map((c) => `
      <button class="course-row ${state.course.toLowerCase() === c.course.toLowerCase() ? 'active' : ''}" data-course="${esc(c.course)}">
        <span class="name" title="${esc(c.course)}">${esc(c.course)}</span>
        <span class="track"><span class="fill" style="width:${(c.count / max) * 100}%"></span></span>
        <span class="count">${c.count}</span>
      </button>`).join('');
  }

  function renderCourseOptions() {
    const select = $('#courseFilter');
    select.innerHTML = '<option value="">All courses</option>' +
      state.courses.map((c) => `<option value="${esc(c)}">${esc(c)}</option>`).join('');
    select.value = state.course;
    $('#courseList').innerHTML = state.courses.map((c) => `<option value="${esc(c)}">`).join('');
  }

  // ---------- List ----------
  function showSkeleton() {
    $('#results').innerHTML = `<div class="grid">${'<div class="skeleton"></div>'.repeat(state.limit > 4 ? 4 : state.limit)}</div>`;
  }

  async function loadStudents() {
    showSkeleton();
    const [sortBy, order] = state.sort.split(':');
    const params = new URLSearchParams({ page: state.page, limit: state.limit, sortBy, order });
    if (state.search) params.set('search', state.search);
    if (state.course) params.set('course', state.course);
    if (state.year) params.set('year', state.year);

    try {
      const { data, meta } = await api(`/students?${params}`);
      // Page no longer exists (e.g. last item on it was deleted) → step back
      if (data.length === 0 && meta.total > 0 && state.page > 1) {
        state.page = meta.totalPages;
        return loadStudents();
      }
      state.items = data;
      renderResults();
      renderPagination(meta);
    } catch (err) {
      $('#results').innerHTML = `
        <div class="empty">
          <div class="big">🔌</div>
          <h3>Can't reach the API</h3>
          <p>${esc(err.message)}. Make sure the server is running (<code>npm start</code>).</p>
          <button class="btn primary" id="retryBtn">Try again</button>
        </div>`;
      $('#pagination').innerHTML = '';
    }
  }

  function cardHtml(s, i) {
    return `
      <article class="card" style="--hue:${hue(s.name)}; animation-delay:${i * 40}ms">
        <div class="card-top">
          <div class="avatar">${esc(initials(s.name))}</div>
          <div class="who"><h3 title="${esc(s.name)}">${esc(s.name)}</h3><p title="${esc(s.email)}">${esc(s.email)}</p></div>
          <div class="actions">
            <button class="icon-btn" data-edit="${s.id}" title="Edit" aria-label="Edit ${esc(s.name)}">${ICON.edit}</button>
            <button class="icon-btn danger" data-del="${s.id}" title="Delete" aria-label="Delete ${esc(s.name)}">${ICON.trash}</button>
          </div>
        </div>
        <div class="tags">
          <span class="tag course">${esc(s.course)}</span>
          <span class="tag">Year ${s.year}</span>
          <span class="tag">Age ${s.age}</span>
        </div>
        <div class="${tier(s.cgpa)}">
          <div class="cgpa-label"><span>CGPA</span><strong>${s.cgpa ?? '—'}</strong></div>
          <div class="bar"><i style="width:${(s.cgpa ?? 0) * 10}%"></i></div>
        </div>
      </article>`;
  }

  function rowHtml(s) {
    return `
      <tr style="--hue:${hue(s.name)}">
        <td><div class="cell-who"><div class="avatar sm">${esc(initials(s.name))}</div><div><b>${esc(s.name)}</b><span>${esc(s.email)}</span></div></div></td>
        <td><span class="tag course">${esc(s.course)}</span></td>
        <td>Year ${s.year}</td>
        <td>${s.age}</td>
        <td><div class="cell-cgpa ${tier(s.cgpa)}"><strong>${s.cgpa ?? '—'}</strong><div class="bar"><i style="width:${(s.cgpa ?? 0) * 10}%"></i></div></div></td>
        <td><div class="row-actions">
          <button class="icon-btn" data-edit="${s.id}" title="Edit" aria-label="Edit ${esc(s.name)}">${ICON.edit}</button>
          <button class="icon-btn danger" data-del="${s.id}" title="Delete" aria-label="Delete ${esc(s.name)}">${ICON.trash}</button>
        </div></td>
      </tr>`;
  }

  function renderResults() {
    const box = $('#results');
    if (state.items.length === 0) {
      const filtered = state.search || state.course || state.year;
      box.innerHTML = `
        <div class="empty">
          <div class="big">${filtered ? '🔍' : '🎒'}</div>
          <h3>${filtered ? 'No students match your filters' : 'No students yet'}</h3>
          <p>${filtered ? 'Try a different search or clear the filters.' : 'Add your first student to get started.'}</p>
          ${filtered ? '<button class="btn ghost" id="clearBtn">Clear filters</button>' : ''}
          <button class="btn primary" id="emptyAdd">Add student</button>
        </div>`;
      return;
    }
    box.innerHTML = state.view === 'grid'
      ? `<div class="grid">${state.items.map(cardHtml).join('')}</div>`
      : `<div class="table-wrap"><table>
          <thead><tr><th>Student</th><th>Course</th><th>Year</th><th>Age</th><th>CGPA</th><th></th></tr></thead>
          <tbody>${state.items.map(rowHtml).join('')}</tbody></table></div>`;
  }

  function pageList(current, total) {
    const pages = new Set([1, total, current - 1, current, current + 1]);
    const sorted = [...pages].filter((p) => p >= 1 && p <= total).sort((a, b) => a - b);
    const out = [];
    sorted.forEach((p, i) => {
      if (i && p - sorted[i - 1] > 1) out.push('…');
      out.push(p);
    });
    return out;
  }

  function renderPagination(meta) {
    const nav = $('#pagination');
    if (meta.total === 0) { nav.innerHTML = ''; return; }
    const from = (meta.page - 1) * meta.limit + 1;
    const to = Math.min(meta.page * meta.limit, meta.total);
    nav.innerHTML = `
      <span class="info">Showing <b>${from}–${to}</b> of <b>${meta.total}</b> students</span>
      <div class="pages">
        <button data-page="${meta.page - 1}" ${meta.page <= 1 ? 'disabled' : ''} aria-label="Previous page">‹</button>
        ${pageList(meta.page, meta.totalPages).map((p) =>
          p === '…' ? '<button disabled>…</button>'
                    : `<button data-page="${p}" class="${p === meta.page ? 'on' : ''}">${p}</button>`).join('')}
        <button data-page="${meta.page + 1}" ${meta.page >= meta.totalPages ? 'disabled' : ''} aria-label="Next page">›</button>
      </div>`;
  }

  function setView(view) {
    state.view = view;
    localStorage.setItem('view', view);
    $('#viewGrid').classList.toggle('on', view === 'grid');
    $('#viewTable').classList.toggle('on', view === 'table');
    renderResults();
  }

  function resetFilters() {
    state.search = ''; state.course = ''; state.year = ''; state.page = 1;
    $('#search').value = ''; $('#courseFilter').value = ''; $('#yearFilter').value = '';
    loadStudents();
    loadStats(); // refreshes the "active" highlight on the course bars
  }

  // ---------- Add / Edit form ----------
  const formDialog = $('#formDialog');
  const form = $('#studentForm');

  function clearErrors() {
    form.querySelectorAll('.err').forEach((e) => (e.textContent = ''));
    form.querySelectorAll('.field').forEach((f) => f.classList.remove('invalid'));
    $('#formError').hidden = true;
  }

  function showFieldError(field, message) {
    const err = form.querySelector(`[data-err="${field}"]`);
    if (!err) return false;
    err.textContent = `${field[0].toUpperCase()}${field.slice(1)} ${message}`;
    err.closest('.field').classList.add('invalid');
    return true;
  }

  function openForm(student) {
    clearErrors();
    form.reset();
    state.editingId = student ? student.id : null;
    $('#formTitle').textContent = student ? 'Edit student' : 'Add student';
    $('#saveBtn').textContent = student ? 'Save changes' : 'Add student';
    if (student) {
      for (const key of ['name', 'email', 'age', 'year', 'course', 'cgpa']) form.elements[key].value = student[key] ?? '';
    }
    formDialog.showModal();
    form.elements.name.focus();
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearErrors();

    const v = (k) => form.elements[k].value.trim();
    const payload = { name: v('name'), email: v('email'), course: v('course') };
    if (v('age') !== '') payload.age = Number(v('age'));
    if (v('year') !== '') payload.year = Number(v('year'));
    if (v('cgpa') !== '') payload.cgpa = Number(v('cgpa'));
    // Empty text fields are sent as '' so the server reports them as invalid
    // (the server is the single source of truth for validation rules).

    const editing = state.editingId;
    const btn = $('#saveBtn');
    btn.disabled = true;
    btn.textContent = 'Saving…';
    try {
      await api(editing ? `/students/${editing}` : '/students', {
        method: editing ? 'PUT' : 'POST',
        body: JSON.stringify(payload),
      });
      formDialog.close();
      toast(editing ? 'Student updated' : 'Student added');
      await Promise.all([loadStudents(), loadStats()]);
    } catch (err) {
      if (err.details) {
        const unmatched = err.details.filter((d) => !showFieldError(d.field, d.message));
        if (unmatched.length) { $('#formError').textContent = unmatched.map((d) => `${d.field} ${d.message}`).join(', '); $('#formError').hidden = false; }
      } else {
        $('#formError').textContent = err.message; // e.g. 409 duplicate email
        $('#formError').hidden = false;
        if (err.status === 409) form.elements.email.closest('.field').classList.add('invalid');
      }
    } finally {
      btn.disabled = false;
      btn.textContent = editing ? 'Save changes' : 'Add student';
    }
  });

  // ---------- Delete ----------
  const confirmDialog = $('#confirmDialog');

  function askDelete(id) {
    const s = state.items.find((x) => x.id === id);
    if (!s) return;
    state.deleteId = id;
    $('#confirmText').textContent = `${s.name} will be permanently removed. This can't be undone.`;
    confirmDialog.showModal();
  }

  $('#confirmDelete').addEventListener('click', async () => {
    const id = state.deleteId;
    const btn = $('#confirmDelete');
    btn.disabled = true;
    try {
      await api(`/students/${id}`, { method: 'DELETE' });
      confirmDialog.close();
      toast('Student deleted');
      await Promise.all([loadStudents(), loadStats()]);
    } catch (err) {
      confirmDialog.close();
      toast(err.message, 'error');
    } finally {
      btn.disabled = false;
    }
  });

  // ---------- Events ----------
  $('#addBtn').addEventListener('click', () => openForm(null));
  $('#viewGrid').addEventListener('click', () => setView('grid'));
  $('#viewTable').addEventListener('click', () => setView('table'));

  $('#search').addEventListener('input', debounce((e) => {
    state.search = e.target.value.trim(); state.page = 1; loadStudents();
  }));
  $('#courseFilter').addEventListener('change', (e) => { state.course = e.target.value; state.page = 1; loadStudents(); loadStats(); });
  $('#yearFilter').addEventListener('change', (e) => { state.year = e.target.value; state.page = 1; loadStudents(); });
  $('#sortSelect').addEventListener('change', (e) => { state.sort = e.target.value; state.page = 1; loadStudents(); });

  // Delegated clicks (cards, table rows, pagination, course bars, empty-state buttons)
  document.addEventListener('click', (e) => {
    const t = e.target.closest('button');
    if (!t) return;
    if (t.dataset.edit) openForm(state.items.find((s) => s.id === Number(t.dataset.edit)));
    else if (t.dataset.del) askDelete(Number(t.dataset.del));
    else if (t.dataset.page) { state.page = Number(t.dataset.page); loadStudents(); window.scrollTo({ top: $('.toolbar').offsetTop - 90, behavior: 'smooth' }); }
    else if (t.dataset.course) {
      const same = state.course.toLowerCase() === t.dataset.course.toLowerCase();
      state.course = same ? '' : t.dataset.course; state.page = 1;
      $('#courseFilter').value = state.course;
      loadStudents(); loadStats();
    }
    else if (t.id === 'clearBtn') resetFilters();
    else if (t.id === 'emptyAdd') openForm(null);
    else if (t.id === 'retryBtn') { loadStudents(); loadStats(); }
    else if ('close' in t.dataset) t.closest('dialog').close();
  });

  // Click on the dark backdrop closes a dialog
  document.querySelectorAll('dialog').forEach((d) =>
    d.addEventListener('click', (e) => { if (e.target === d) d.close(); }));

  // "/" focuses the search box
  document.addEventListener('keydown', (e) => {
    const typing = /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName);
    if (e.key === '/' && !typing && !document.querySelector('dialog[open]')) {
      e.preventDefault();
      $('#search').focus();
    }
  });

  // ---------- Init ----------
  renderThemeIcon();
  setView(state.view);
  loadStats();
  loadStudents();
})();
