require('dotenv').config();
const app = require('./app');

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => { console.log(`Dashboard: http://localhost:${PORT}`); console.log(`REST API:  http://localhost:${PORT}/api`); });
