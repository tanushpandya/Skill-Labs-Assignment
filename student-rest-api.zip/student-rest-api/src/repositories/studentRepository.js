// Data layer. Students live in a JSON file so data survives restarts,
// with no database setup. To move to MongoDB/Postgres later, only this
// file needs to change.
const fs = require('fs/promises');
const path = require('path');

const filePath = () =>
  process.env.DATA_FILE || path.join(__dirname, '..', 'data', 'students.json');

let cache = null;

async function load() {
  if (cache) return cache;
  try {
    cache = JSON.parse(await fs.readFile(filePath(), 'utf8'));
  } catch (err) {
    if (err.code !== 'ENOENT') throw err;
    cache = { nextId: 1, students: [] };
  }
  return cache;
}

async function save() {
  await fs.writeFile(filePath(), JSON.stringify(cache, null, 2));
}

const findAll = async () => (await load()).students;

const findById = async (id) => (await load()).students.find((s) => s.id === id);

const findByEmail = async (email) =>
  (await load()).students.find((s) => s.email.toLowerCase() === email.toLowerCase());

async function create(data) {
  const db = await load();
  const now = new Date().toISOString();
  const student = { id: db.nextId++, ...data, createdAt: now, updatedAt: now };
  db.students.push(student);
  await save();
  return student;
}

async function update(id, data) {
  const db = await load();
  const index = db.students.findIndex((s) => s.id === id);
  if (index === -1) return undefined;
  const { id: sid, createdAt } = db.students[index];
  db.students[index] = { id: sid, ...data, createdAt, updatedAt: new Date().toISOString() };
  await save();
  return db.students[index];
}

async function remove(id) {
  const db = await load();
  const index = db.students.findIndex((s) => s.id === id);
  if (index === -1) return false;
  db.students.splice(index, 1);
  await save();
  return true;
}

// Used by tests to start from a clean slate.
const _resetCache = () => { cache = null; };

module.exports = { findAll, findById, findByEmail, create, update, remove, _resetCache };
