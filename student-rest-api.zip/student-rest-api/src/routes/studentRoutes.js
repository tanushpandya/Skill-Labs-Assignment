const router = require('express').Router();
const c = require('../controllers/studentController');
const validateStudent = require('../middleware/validateStudent');

// Express 4 doesn't catch rejected promises, so wrap async handlers.
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

router.get('/', wrap(c.list));
router.post('/', validateStudent(), wrap(c.create));
router.get('/:id', wrap(c.getOne));
router.put('/:id', validateStudent(), wrap(c.replace));
router.patch('/:id', validateStudent({ partial: true }), wrap(c.patch));
router.delete('/:id', wrap(c.remove));

module.exports = router;
