// An error that carries an HTTP status code, so controllers can simply `throw`.
class AppError extends Error {
  constructor(message, status = 500, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

module.exports = AppError;
