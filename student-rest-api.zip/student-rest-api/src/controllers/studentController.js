const repo = require('../repositories/studentRepository');
const AppError = require('../utils/AppError');

const SORTABLE = ['id', 'name', 'age', 'year', 'cgpa', 'createdAt'];

function parseId(raw) {
  const id = Number(raw);
  if (!Number.isInteger(id) || id < 1) throw new AppError('Student id must be a positive integer', 400);
  return id;
}

async function getOrThrow(rawId) {
  const student = await repo.findById(parseId(rawId));
  if (!student) throw new AppError(`Student with id ${rawId} not found`, 404);
  return student;
}

async function assertEmailFree(email, ignoreId) {
  const existing = await repo.findByEmail(email);
  if (existing && existing.id !== ignoreId) {
    throw new AppError(`A student with email ${email} already exists`, 409);
  }
}

// GET /api/students?search=&course=&year=&minCgpa=&sortBy=&order=&page=&limit=
exports.list = async (req, res) => {
  const { search, course, year, minCgpa, sortBy = 'id', order = 'asc' } = req.query;
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 10, 1), 100);

  if (!SORTABLE.includes(sortBy)) {
    throw new AppError(`sortBy must be one of: ${SORTABLE.join(', ')}`, 400);
  }
  if (!['asc', 'desc'].includes(order)) throw new AppError('order must be asc or desc', 400);

  let students = [...(await repo.findAll())];

  if (search) {
    const q = search.toLowerCase();
    students = students.filter(
      (s) => s.name.toLowerCase().includes(q) || s.email.toLowerCase().includes(q)
    );
  }
  if (course) students = students.filter((s) => s.course.toLowerCase() === course.toLowerCase());
  if (year) students = students.filter((s) => s.year === Number(year));
  if (minCgpa) students = students.filter((s) => (s.cgpa ?? -1) >= Number(minCgpa));

  students.sort((a, b) => {
    const x = a[sortBy], y = b[sortBy];
    const cmp = typeof x === 'string' ? x.localeCompare(y) : (x ?? 0) - (y ?? 0);
    return order === 'asc' ? cmp : -cmp;
  });

  const total = students.length;
  const data = students.slice((page - 1) * limit, page * limit);
  res.json({ data, meta: { total, page, limit, totalPages: Math.ceil(total / limit) } });
};

// GET /api/students/:id
exports.getOne = async (req, res) => {
  res.json({ data: await getOrThrow(req.params.id) });
};

// POST /api/students
exports.create = async (req, res) => {
  await assertEmailFree(req.validated.email);
  const student = await repo.create(req.validated);
  res.status(201).location(`/api/students/${student.id}`).json({ data: student });
};

// PUT /api/students/:id  (replace the whole record)
exports.replace = async (req, res) => {
  const existing = await getOrThrow(req.params.id);
  await assertEmailFree(req.validated.email, existing.id);
  res.json({ data: await repo.update(existing.id, req.validated) });
};

// PATCH /api/students/:id  (change only the fields sent)
exports.patch = async (req, res) => {
  const existing = await getOrThrow(req.params.id);
  if (req.validated.email) await assertEmailFree(req.validated.email, existing.id);
  const { id, createdAt, updatedAt, ...current } = existing;
  res.json({ data: await repo.update(existing.id, { ...current, ...req.validated }) });
};

// DELETE /api/students/:id
exports.remove = async (req, res) => {
  const existing = await getOrThrow(req.params.id);
  await repo.remove(existing.id);
  res.status(204).send();
};
