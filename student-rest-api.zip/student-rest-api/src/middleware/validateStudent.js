const AppError = require('../utils/AppError');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// field -> validator returning an error message (or undefined when valid)
const rules = {
  name: (v) =>
    typeof v === 'string' && v.trim().length >= 2 && v.trim().length <= 100
      ? undefined : 'must be a string of 2-100 characters',
  email: (v) =>
    typeof v === 'string' && EMAIL_RE.test(v.trim()) ? undefined : 'must be a valid email address',
  age: (v) =>
    Number.isInteger(v) && v >= 15 && v <= 100 ? undefined : 'must be an integer between 15 and 100',
  course: (v) =>
    typeof v === 'string' && v.trim().length >= 2 && v.trim().length <= 100
      ? undefined : 'must be a string of 2-100 characters',
  year: (v) =>
    Number.isInteger(v) && v >= 1 && v <= 6 ? undefined : 'must be an integer between 1 and 6',
  cgpa: (v) =>
    typeof v === 'number' && v >= 0 && v <= 10 ? undefined : 'must be a number between 0 and 10',
};

const REQUIRED = ['name', 'email', 'age', 'course', 'year']; // cgpa is optional

// Builds a middleware. `partial: true` is for PATCH (every field optional,
// but at least one must be present).
function validateStudent({ partial = false } = {}) {
  return (req, res, next) => {
    const body = req.body;
    if (!body || typeof body !== 'object' || Array.isArray(body)) {
      return next(new AppError('Request body must be a JSON object', 400));
    }

    const details = [];
    const clean = {};

    for (const field of Object.keys(rules)) {
      const value = body[field];
      if (value === undefined) {
        if (!partial && REQUIRED.includes(field)) details.push({ field, message: 'is required' });
        continue;
      }
      const message = rules[field](value);
      if (message) details.push({ field, message });
      else clean[field] = typeof value === 'string' ? value.trim() : value;
    }

    if (partial && Object.keys(body).length === 0) {
      details.push({ field: 'body', message: 'provide at least one field to update' });
    }

    if (details.length) return next(new AppError('Validation failed', 400, details));

    req.validated = clean; // only known, cleaned fields reach the controller
    next();
  };
}

module.exports = validateStudent;
