const AppError = require('../utils/AppError');

const notFound = (req, res, next) =>
  next(new AppError(`Route not found: ${req.method} ${req.originalUrl}`, 404));

// eslint-disable-next-line no-unused-vars
const errorHandler = (err, req, res, next) => {
  // Malformed JSON in the request body
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: { message: 'Invalid JSON in request body' } });
  }

  const status = err.status || 500;
  if (status === 500) console.error(err);

  res.status(status).json({
    error: {
      message: status === 500 ? 'Internal server error' : err.message,
      ...(err.details && { details: err.details }),
    },
  });
};

module.exports = { notFound, errorHandler };
