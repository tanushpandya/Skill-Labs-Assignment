// Run with: npm test   (uses Node's built-in test runner, no extra packages)
process.env.NODE_ENV = 'test';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');

const tmp = path.join(os.tmpdir(), `students-test-${process.pid}.json`);
process.env.DATA_FILE = tmp; // never touch the real data file

const app = require('../src/app');
let server, base;

before(async () => {
  await new Promise((resolve) => { server = app.listen(0, resolve); });
  base = `http://localhost:${server.address().port}/api`;
});
after(() => { server.close(); fs.rmSync(tmp, { force: true }); });

const call = async (method, url, body) => {
  const res = await fetch(base + url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  return { status: res.status, body: text ? JSON.parse(text) : null };
};

const sample = { name: 'Test Student', email: 'test@example.com', age: 20, course: 'Civil Engineering', year: 2 };

test('full CRUD lifecycle', async () => {
  const created = await call('POST', '/students', sample);
  assert.equal(created.status, 201);
  const id = created.body.data.id;

  assert.equal((await call('GET', `/students/${id}`)).body.data.email, sample.email);

  const patched = await call('PATCH', `/students/${id}`, { cgpa: 9.5 });
  assert.equal(patched.body.data.cgpa, 9.5);
  assert.equal(patched.body.data.name, sample.name); // untouched field kept

  const replaced = await call('PUT', `/students/${id}`, { ...sample, name: 'Renamed', year: 3 });
  assert.equal(replaced.body.data.name, 'Renamed');

  assert.equal((await call('DELETE', `/students/${id}`)).status, 204);
  assert.equal((await call('GET', `/students/${id}`)).status, 404);
});

test('validation errors return 400 with details', async () => {
  const res = await call('POST', '/students', { name: 'A', email: 'nope', age: 5 });
  assert.equal(res.status, 400);
  assert.ok(res.body.error.details.length >= 4);
});

test('duplicate email returns 409', async () => {
  await call('POST', '/students', { ...sample, email: 'dup@example.com' });
  const res = await call('POST', '/students', { ...sample, email: 'DUP@example.com' });
  assert.equal(res.status, 409);
});

test('list supports search, sorting and pagination', async () => {
  for (const [i, name] of ['Zed', 'Amy', 'Bob'].entries()) {
    await call('POST', '/students', { ...sample, name: `${name} Person`, email: `p${i}@example.com` });
  }
  const sorted = await call('GET', '/students?search=person&sortBy=name&order=asc&limit=2');
  assert.deepEqual(sorted.body.data.map((s) => s.name), ['Amy Person', 'Bob Person']);
  assert.equal(sorted.body.meta.total, 3);
  assert.equal(sorted.body.meta.totalPages, 2);
});

test('bad id and unknown route', async () => {
  assert.equal((await call('GET', '/students/abc')).status, 400);
  assert.equal((await call('GET', '/nothing')).status, 404);
});
