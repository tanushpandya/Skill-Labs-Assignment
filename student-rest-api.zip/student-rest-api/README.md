# Student REST API

A student management REST API built with **Node.js + Express**, with a ready-made **Postman** collection.

## Features
- Full CRUD: create, read, update (PUT + PATCH) and delete students
- Search, filter, sort and pagination on the list endpoint
- Input validation with clear, field-level error messages
- Consistent JSON responses and correct HTTP status codes (200, 201, 204, 400, 404, 409)
- Layered structure (routes → controllers → repository) that is easy to extend
- Data saved to a JSON file, so no database setup is needed
- Automated tests (Node's built-in test runner) and a Postman collection with 23 test assertions

## Quick start
```bash
npm install
cp .env.example .env     # optional, default port is 3000
npm start                # or: npm run dev  (auto-restart with nodemon)
```
The API is now at `http://localhost:3000/api`.

Run the tests: `npm test`

## Project structure
```
src/
  app.js                    Express app (middleware + routes)
  server.js                 Starts the server
  routes/studentRoutes.js   URL → controller mapping
  controllers/              Request handling logic
  repositories/             Data access (JSON file) - swap for a real DB later
  middleware/               Validation + error handling
  utils/AppError.js         Error with an HTTP status
  data/students.json        Seed data
postman/                    Collection + environment
test/                       Automated API tests
```

## Endpoints
| Method | URL | Description | Success |
|--------|-----|-------------|---------|
| GET | `/api/health` | Server health check | 200 |
| GET | `/api/students` | List students (search / filter / sort / paginate) | 200 |
| GET | `/api/students/:id` | Get one student | 200 |
| POST | `/api/students` | Create a student | 201 |
| PUT | `/api/students/:id` | Replace a student (all required fields) | 200 |
| PATCH | `/api/students/:id` | Update only the fields sent | 200 |
| DELETE | `/api/students/:id` | Delete a student | 204 |

### Student fields
| Field | Type | Rules |
|-------|------|-------|
| `name` | string | required, 2-100 chars |
| `email` | string | required, valid format, unique |
| `age` | integer | required, 15-100 |
| `course` | string | required, 2-100 chars |
| `year` | integer | required, 1-6 |
| `cgpa` | number | optional, 0-10 |

`id`, `createdAt` and `updatedAt` are set by the server.

### List query parameters
`search` (name or email), `course`, `year`, `minCgpa`, `sortBy` (`id|name|age|year|cgpa|createdAt`), `order` (`asc|desc`), `page`, `limit` (max 100)

Example: `GET /api/students?course=Civil Engineering&sortBy=cgpa&order=desc&page=1&limit=5`

### Example
```bash
curl -X POST http://localhost:3000/api/students \
  -H "Content-Type: application/json" \
  -d '{"name":"Meera Nair","email":"meera@example.com","age":20,"course":"Civil Engineering","year":2,"cgpa":8.7}'
```
Response (201):
```json
{ "data": { "id": 4, "name": "Meera Nair", "email": "meera@example.com", "age": 20,
            "course": "Civil Engineering", "year": 2, "cgpa": 8.7,
            "createdAt": "...", "updatedAt": "..." } }
```
Error response (400):
```json
{ "error": { "message": "Validation failed",
             "details": [ { "field": "email", "message": "must be a valid email address" } ] } }
```

## Using Postman
1. Start the server (`npm start`).
2. In Postman: **Import** → select both files in the `postman/` folder.
3. Choose the **Student API - Local** environment (top-right dropdown).
4. Try requests one by one, or click the collection → **Run** to execute all 12 in order. Each request has tests (the **Tests** tab) and the *Create student* request saves the new id into `{{studentId}}` for the requests after it.

Command-line alternative: `npx newman run postman/Student-API.postman_collection.json -e postman/Student-API.postman_environment.json`

## Ideas to extend it (good for learning)
- Replace the JSON file with MongoDB (Mongoose) or SQLite/PostgreSQL by rewriting only `studentRepository.js`
- Add JWT authentication (register/login) and protect POST/PUT/PATCH/DELETE
- Add a `courses` resource and link students to courses
- Add Swagger/OpenAPI docs with `swagger-ui-express`
- Add rate limiting (`express-rate-limit`) and security headers (`helmet`)
